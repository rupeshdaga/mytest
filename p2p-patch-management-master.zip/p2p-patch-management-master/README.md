# Introduction 
Peer2Peer Patch Management solution for Cisco IOS/IOS-XE
# Getting Started
Please ensure patchmgmtdata.xlsx is up to data with latest patch management standard.
All required firmwares need to go in Firmware directory

